const form = document.getElementById('surveyForm');
const statusBox = document.getElementById('formStatus');

function setStatus(type, message) {
  statusBox.className = `form-status show ${type}`;
  statusBox.textContent = message;
}

function clearStatus() {
  statusBox.className = 'form-status';
  statusBox.textContent = '';
}

function getFormData(formElement) {
  const formData = new FormData(formElement);
  return {
    name: formData.get('name')?.trim(),
    email: formData.get('email')?.trim(),
    modality: formData.get('modality')?.trim(),
    superResolutionStructures: formData.get('superResolutionStructures')?.trim(),
    fluorophores: formData.get('fluorophores')?.trim(),
    sampleMounting: formData.get('sampleMounting')?.trim(),
    sampleDescription: formData.get('sampleDescription')?.trim(),
    magnifications: formData.getAll('magnifications'),
    liveSampleNeeds: formData.get('liveSampleNeeds')?.trim(),
    timelapseNeed: formData.get('timelapseNeed')?.trim(),
    currentMicroscopes: formData.get('currentMicroscopes')?.trim(),
    hopedInformation: formData.get('hopedInformation')?.trim(),
    otherItems: formData.get('otherItems')?.trim()
  };
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  clearStatus();

  if (!form.reportValidity()) {
    setStatus('error', 'Please complete the required fields before submitting.');
    return;
  }

  const submitButton = form.querySelector('button[type="submit"]');
  const originalLabel = submitButton.textContent;
  submitButton.disabled = true;
  submitButton.textContent = 'Submitting...';

  try {
    const payload = getFormData(form);
    const response = await fetch('/api/survey', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || 'Something went wrong.');
    }

    setStatus('success', 'Thank you. Your survey was submitted successfully, and a confirmation email is on its way.');
    form.reset();
    window.scrollTo({ top: form.offsetTop - 120, behavior: 'smooth' });
  } catch (error) {
    setStatus('error', error.message || 'There was a problem submitting the survey. Please try again.');
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = originalLabel;
  }
});
