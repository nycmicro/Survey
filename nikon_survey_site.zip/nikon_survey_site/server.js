const path = require('path');
const express = require('express');
const nodemailer = require('nodemailer');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const RECIPIENT_EMAIL = process.env.RECIPIENT_EMAIL || 'Lauren.Richmond@nikon.com';

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function escapeHtml(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatCheckboxes(values) {
  if (!Array.isArray(values) || values.length === 0) return 'Not provided';
  return values.join(', ');
}

function buildInternalEmail(data) {
  const rows = [
    ['Responder name', data.name],
    ['Responder email', data.email],
    ['1. Which modality would most benefit your research?', data.modality],
    ['2. If interested in super-resolution, what structures are you hoping to observe?', data.superResolutionStructures || 'Not provided'],
    ['3. What fluorophores are you interested in imaging?', data.fluorophores || 'Not provided'],
    ['4. How is your sample mounted?', data.sampleMounting || 'Not provided'],
    ['5. Please describe your sample.', data.sampleDescription || 'Not provided'],
    ['6. What magnification(s) do you typically use?', formatCheckboxes(data.magnifications)],
    ['7. Is your sample live? Will you require temperature, CO2 or humidity control?', data.liveSampleNeeds || 'Not provided'],
    ['8. Do you have a need for long-term timelapse imaging?', data.timelapseNeed || 'Not provided'],
    ['9. What microscope(s) do you currently use? Any likes/dislikes?', data.currentMicroscopes || 'Not provided'],
    ['10. What information about your sample do you hope to obtain from this potential demonstration?', data.hopedInformation || 'Not provided'],
    ['11. Are there any other items you would like to address?', data.otherItems || 'Not provided']
  ];

  const tableRows = rows
    .map(([label, value]) => `
      <tr>
        <td style="padding:12px 14px;border:1px solid #d9d9d9;background:#f7f7f7;font-weight:600;vertical-align:top;width:34%;">${escapeHtml(label)}</td>
        <td style="padding:12px 14px;border:1px solid #d9d9d9;white-space:pre-wrap;">${escapeHtml(value)}</td>
      </tr>`)
    .join('');

  return `
    <div style="font-family:Arial,Helvetica,sans-serif;color:#111;line-height:1.5;">
      <div style="background:#111;color:#fff;padding:20px 24px;">
        <div style="font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#ffd100;">Nikon Survey Submission</div>
        <h1 style="margin:8px 0 0;font-size:24px;">New Ti2 with W1 SoRa survey response</h1>
      </div>
      <div style="padding:24px;">
        <p style="margin-top:0;">A new survey was submitted for the <strong>Nikon Ti2 with W1 SoRa Demonstration at NYU Langone</strong>.</p>
        <table style="border-collapse:collapse;width:100%;font-size:14px;">${tableRows}</table>
        <p style="margin:24px 0 0;font-size:13px;color:#555;">Submitted from the survey webpage.</p>
      </div>
    </div>`;
}

function buildConfirmationEmail(data) {
  const magnifications = Array.isArray(data.magnifications) && data.magnifications.length
    ? data.magnifications.join(', ')
    : 'Not provided';

  return `
    <div style="font-family:Arial,Helvetica,sans-serif;color:#111;line-height:1.6;">
      <div style="background:#111;color:#fff;padding:20px 24px;">
        <div style="font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#ffd100;">Thank you</div>
        <h1 style="margin:8px 0 0;font-size:24px;">Your Nikon SoRa survey response was received</h1>
      </div>
      <div style="padding:24px;">
        <p>Hi ${escapeHtml(data.name)},</p>
        <p>Thank you for completing the survey for the <strong>Nikon Ti2 with W1 SoRa Demonstration at NYU Langone</strong>. Your responses have been sent to Lauren Richmond.</p>
        <div style="margin:20px 0;padding:18px;border:1px solid #e5e5e5;border-left:5px solid #ffd100;background:#fafafa;">
          <p style="margin:0 0 8px;"><strong>Submitted email:</strong> ${escapeHtml(data.email)}</p>
          <p style="margin:0 0 8px;"><strong>Selected modality:</strong> ${escapeHtml(data.modality)}</p>
          <p style="margin:0;"><strong>Magnifications:</strong> ${escapeHtml(magnifications)}</p>
        </div>
        <p>If you need to add anything else, you can reply directly to Lauren at <a href="mailto:${escapeHtml(RECIPIENT_EMAIL)}">${escapeHtml(RECIPIENT_EMAIL)}</a>.</p>
        <p style="margin-bottom:0;">
          Best regards,<br>
          Nikon Instruments
        </p>
      </div>
    </div>`;
}

function validatePayload(data) {
  const requiredFields = ['name', 'email', 'modality'];
  for (const field of requiredFields) {
    if (!data[field] || !String(data[field]).trim()) {
      return `Missing required field: ${field}`;
    }
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(String(data.email).trim())) {
    return 'Please provide a valid email address.';
  }

  return null;
}

app.post('/api/survey', async (req, res) => {
  const data = req.body || {};
  const validationError = validatePayload(data);

  if (validationError) {
    return res.status(400).json({ ok: false, message: validationError });
  }

  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS || !process.env.SMTP_FROM) {
    return res.status(500).json({
      ok: false,
      message: 'Email is not configured yet. Add your SMTP settings to the environment variables before using the form.'
    });
  }

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE).toLowerCase() === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });

  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM,
      to: RECIPIENT_EMAIL,
      replyTo: data.email,
      subject: `New Nikon SoRa Survey Response — ${data.name}`,
      html: buildInternalEmail(data)
    });

    await transporter.sendMail({
      from: process.env.SMTP_FROM,
      to: data.email,
      replyTo: RECIPIENT_EMAIL,
      subject: 'We received your Nikon SoRa survey response',
      html: buildConfirmationEmail(data)
    });

    return res.json({ ok: true, message: 'Survey submitted successfully.' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      ok: false,
      message: 'There was a problem sending the emails. Please check your SMTP settings and try again.'
    });
  }
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Nikon survey site running on http://localhost:${PORT}`);
});
